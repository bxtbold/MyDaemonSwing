package com.ur.urcap.examples.mydaemonswing.impl;

import com.ur.urcap.api.contribution.installation.swing.SwingInstallationNodeView;

import javax.swing.*;


public class MyDaemonInstallationNodeView implements SwingInstallationNodeView<MyDaemonInstallationNodeContribution> {

	public MyDaemonInstallationNodeView() {
	}

	@Override
	public void buildUI(JPanel panel, MyDaemonInstallationNodeContribution contribution) {
	}
}
