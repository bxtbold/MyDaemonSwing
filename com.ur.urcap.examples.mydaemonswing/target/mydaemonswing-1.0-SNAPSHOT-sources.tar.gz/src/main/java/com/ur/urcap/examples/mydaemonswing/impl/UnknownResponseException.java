package com.ur.urcap.examples.mydaemonswing.impl;

public class UnknownResponseException extends Exception {
}
